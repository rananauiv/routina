ROUTINA PLUS v3 SOURCE

Rogue's player-facing name is Warrior. The legacy internal name is retained for save compatibility.
The ledger reward cooldown is measured in minutes (default 3, range 1-1440), set in Settings > Ledger.

BUILD THE EXECUTABLE
  Windows: double-click build_exe.bat
  macOS/Linux: ./build_exe.sh
Requires Python 3.10+ with Tkinter. Output appears in dist/.
Optional: pip install matplotlib (for charts).
