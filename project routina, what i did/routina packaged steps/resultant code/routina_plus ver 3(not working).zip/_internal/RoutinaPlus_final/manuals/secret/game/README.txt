FOR THY LORD — HIDDEN GAME GUIDE

OPEN THE GAME
1. Complete 100 tasks and habits combined. This is a lifetime total and does not reset weekly.
2. When the 100th combined completion is recorded, Routina presents a riddle. It hints at the task name to enter; it does not appear at startup.
3. Enter the answer as a task named exactly "for thy lord" in lowercase. A Go to game button then appears on Home and Tasks. Clicking it opens the hidden game.
4. EARLY-ACCESS OVERRIDE: If you already know the task name, adding "for thy lord" opens the game before 100 completions. The task does not need to be completed.
5. If the riddle was closed, press Ctrl+Shift+G in Routina after reaching 100 completions to show it again.
6. The world map can be viewed without a completed task or any units. Complete at least one task or habit this week to participate in raids or Pit Fight. You can still open a hostile region and scout it without owning units; deploying a unit is required to start battle.

PIT FIGHT
Pit Fight is a real-time, top-down arena. Select one ready unit from Inventory and an active enemy, or leave the opponent slot empty to spar with a practice dummy. Combat has no on-screen action buttons.

Default controls:
W A S D  Move
Space    Basic attack
Q        Class ability
Shift    Guard
K        Open keybind settings

Change and save the controls in Pit Fight setup or press K during a fight. Archer uses long-range shots and Power Shot; Wizard uses Spark and Frost Nova to slow enemies; Rogue moves fastest and uses Backstab and Shadow Dash. Enemy fighters use class-based AI. Pit fights are friendly: neither fighter is killed. Completing a bout earns tokens. A player win shames the enemy and lowers its level by one, to a minimum of level 1.

BRIBES AND OPEN ENEMY SPOTS
Bribing removes the selected enemy from its roster spot. A defeated enemy also leaves a vacancy. Vacancies remain empty; enemies are not automatically required in every spot. Select a ready unit from Inventory for Pit Fight, and use Spawn enemy in an open spot when you want to fill an enemy vacancy. A Lord can also be bribed, leaving the fortress without a Lord until a new one is spawned. A fortress with no Lord can still be raided; clearing its remaining enemies conquers it.

Each spawn into a fortress that already has an active enemy has a 1-in-20 chance of dying immediately. The first enemy placed into an empty fortress has no spawn-death roll.

TOKEN RATE
The rate is dT/dt = n + v. Here n is the number of tasks/habits completed this week, and v is 5 tokens for each fully conquered region victory. Victories stay in the player's data across new campaigns. The rate pays at each active-play interval dt = 3t', where t' is a random 5–10 minutes (so dt is 15–30 minutes). A region victory adds 5 to the ongoing rate; it is not a one-time payment.

CHEAT CODE
After defeating three Lords, the Game Menu reveals Cheat Code. Enter the sequence with individual keyboard presses to unlock unlimited token spending:
up up down down left left right right ab ab

The cheat does not create or complete tasks. The weekly completion requirement remains in effect.

