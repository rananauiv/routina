#!/bin/sh
python3 -m pip install --upgrade pip pyinstaller matplotlib pillow pygame-ce || { echo "Dependency install failed."; exit 1; }
python3 -m PyInstaller --noconfirm --onefile --windowed --name RoutinaPlus routina_plus.py
echo "Done. See dist/RoutinaPlus"
