@echo off
python -m pip install --upgrade pip pyinstaller matplotlib pillow pygame-ce
if errorlevel 1 (
  echo Dependency install failed.
  pause
  exit /b 1
)
python -m PyInstaller --noconfirm --onefile --windowed --name RoutinaPlus routina_plus.py
echo Done. See dist\RoutinaPlus.exe
pause
