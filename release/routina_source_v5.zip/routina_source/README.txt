ROUTINA PLUS

Rogue's player-facing name is Warrior. The legacy internal name is retained for save compatibility.

REWARD LEDGER (token chest)
Every completed task or habit becomes an income stream that pays 10 tokens per interval while the app
is running, so the payout grows as you complete more (3 completions = 30 tokens per interval).
Set the interval in SECONDS under Settings > Reward ledger (default 60 = 1 minute; 1 = every second).
Time while the app is closed is not paid.
Interval 0 = no timer: nothing pays automatically, and every click of "Get tokens" (or the token badge)
pays the full amount. With no completions there is nothing to pay.
Minute settings saved by earlier builds are converted to seconds automatically.

GAME
Moving never needs a new round and can be repeated freely. Only attacking is limited to once per
round (NEXT ROUND resets it). Pressing ATTACK on an enemy out of range walks the selected unit into
range first, if its move allows.

BUILD THE EXECUTABLE
  Windows: double-click build_exe.bat
  macOS/Linux: ./build_exe.sh
Requires Python 3.10+ with Tkinter. Output appears in dist/.
Optional: pip install matplotlib (for charts).
