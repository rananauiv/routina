@echo off
python -m pip install --upgrade pyinstaller matplotlib
python -m PyInstaller --noconfirm --onefile --windowed --name RoutinaPlus routina_plus.py
echo Done. See dist\RoutinaPlus.exe
pause
