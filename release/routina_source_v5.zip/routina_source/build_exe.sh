#!/bin/sh
python3 -m pip install --upgrade pyinstaller matplotlib
python3 -m PyInstaller --noconfirm --onefile --windowed --name RoutinaPlus routina_plus.py
echo "Done. See dist/RoutinaPlus"
