"""game_hooks: the single integration point between Routina and the game."""
from __future__ import annotations

import traceback
from datetime import datetime
from pathlib import Path

_db = None
LOG_PATH = Path(__file__).resolve().parent / "routina_errors.log"


def _log(where: str) -> None:
    """Append the current exception to routina_errors.log so failures are never silent."""
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write("[%s] %s\n%s\n" % (datetime.now().isoformat(timespec="seconds"), where,
                                         traceback.format_exc()))
    except OSError:
        pass


def bind(db) -> None:
    """Attach the open Database used to award tokens."""
    global _db
    _db = db


def on_task_completed(task_key: str) -> bool:
    """Award one token for a completion event; duplicate keys (task id + date) award nothing."""
    if _db is None or not task_key:
        return False
    try:
        return _db.award_task(str(task_key))
    except Exception:
        _log("on_task_completed")
        return False


def on_activity_completed(activity_type: str, activity_id, completed_at: str, schedule=None) -> int:
    """Record a task or habit completion in the shared token ledger."""
    if _db is None:
        return 0
    try:
        return _db.award_activity_completion(activity_type, activity_id, completed_at, schedule)
    except Exception:
        _log("on_activity_completed")
        return 0


def token_summary():
    """Return (balance, waiting_count), claiming anything the interval now allows."""
    if _db is None:
        return 0, 0
    try:
        _db.claim_pending()
        return _db.balance()["balance"], _db.pending_count()
    except Exception:
        _log("token_summary")
        return 0, 0


def claim_all() -> int:
    """Manually claim every waiting reward, ignoring the interval."""
    if _db is None:
        return 0
    try:
        return _db.claim_all_now()
    except Exception:
        _log("claim_all")
        return 0
