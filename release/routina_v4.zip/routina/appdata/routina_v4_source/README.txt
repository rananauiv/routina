ROUTINA PLUS v3 SOURCE

Rogue's player-facing name is Warrior. The legacy internal name is retained for save compatibility.
The ledger reward cooldown is measured in minutes (default 3, range 0-1440), set in Settings > Ledger.
Completions blocked by the cooldown wait in the ledger and are paid automatically once it elapses
(or via 'Claim waiting rewards'). An interval of 0 removes the limit: every completion pays 10 tokens at once.

BUILD THE EXECUTABLE
  Windows: double-click build_exe.bat
  macOS/Linux: ./build_exe.sh
Requires Python 3.10+ with Tkinter. Output appears in dist/.
Optional: pip install matplotlib (for charts).
